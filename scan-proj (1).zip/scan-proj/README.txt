pip install -r requirement.txt

python app.py